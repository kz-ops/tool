
Tagging types
-------------

.. toctree::
   :maxdepth: 2

   /docs/type/tag/tag
   /docs/type/tag/tagset
   /docs/type/tag/tagmap
