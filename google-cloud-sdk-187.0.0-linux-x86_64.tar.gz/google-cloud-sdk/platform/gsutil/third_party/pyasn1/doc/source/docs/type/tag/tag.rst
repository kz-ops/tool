
Solitary tag
------------

.. automodule:: pyasn1.type.tag
   :members: Tag, tagClassUniversal, tagClassApplication, tagClassContext,
             tagClassPrivate, tagFormatSimple, tagFormatConstructed

